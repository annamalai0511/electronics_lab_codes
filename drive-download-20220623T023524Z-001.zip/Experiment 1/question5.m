clc;
clear all;
close all;
im=imread("picture.jpg");
[rows,colums,depth]=size(im);
disp(rows);
disp(colums);
pixels=rows*colums;
disp(pixels);