clc;
clear all;
close all;
pic=imread("picture.jpg");
I2=imcrop(pic,[120 100 300 400]);
figure;
imshow(pic);    
figure;
imshow(I2);