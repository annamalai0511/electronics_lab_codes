clc;
close all;
original=imread("picture.jpg");
im=rgb2gray(original);
level=graythresh(im);
og2=im2bw(original,level);
subplot(2,1,1);imshow(original);
subplot(2,1,2);imshow(og2);